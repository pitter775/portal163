<style>
    .titulo{
        font-family: "Montserrat", "Helvetica Neue", Arial, sans-serif;
        font-weight: bold;
        font-size: 20px;
        text-transform: uppercase;
        -webkit-font-smoothing: antialiased;
    }
    .itemmenu{ text-transform: uppercase;  font-size: 15px; font-weight: bold; font-family: "Montserrat", "Helvetica Neue", Arial, sans-serif; float: left; margin-right: 20PX; color: #888; }
    .ativo{ color: #000 !important; }
</style>
<div class="container" >
    <div class="row">
        <div class="col-md-4" style="padding-left: 0;">
            <p class="titulo" style=" margin-top: 40px; color: #000">Novo Progresso News</p>
            <div style="font-size: 10px; margin-top:-20px; color: #006634">NOTICÍAS DA CIDADE</div>
        </div>
        <div class="col-md-8" style="padding-right: 0;">
            <div style="float: right; margin-top: 20px; height: 100px; width: 100%; background: #ccc"></div>
            <img class="img-responsive" style="float: right; margin-top: 20px" src="https://eranews.joomlatema.net/images/top-banner.png" alt="">
        </div>
        <div class="col-md-12" style=" margin-top: 10px; padding-top: 10px; padding-bottom: 10px; border-bottom: solid 1px #006634;">
        <div class="itemmenu {{ $elementActive == 'HOME' ? 'ativo' : '' }}" ><a href="/" class="{{ $elementActive == 'HOME' ? 'ativo' : '' }}">HOME</a></div>
        @foreach($menu as $key => $value)
            <div class="itemmenu {{ $elementActive == '$value->nome' ? 'ativo' : '' }}" data-id="{{$value->id}}"><a href="" class="{{ $elementActive == '$value->nome' ? 'ativo' : '' }}">{{$value->nome}}</a></div>
        @endforeach            
        </div>
    </div>
</div>