<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Users_regiao extends Model
{
    // public $timestamps = false;
}