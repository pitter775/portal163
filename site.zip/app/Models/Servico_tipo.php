<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Servico_tipo extends Model
{
     public $timestamps = false;
}