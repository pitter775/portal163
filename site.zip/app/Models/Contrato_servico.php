<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Contrato_servico extends Model
{
     public $timestamps = false;
}