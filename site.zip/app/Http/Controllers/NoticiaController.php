<?php

namespace App\Http\Controllers;

use App\Models\Categoria;
use Illuminate\Http\Request;
use App\Models\Noticia;
use App\Models\Noticia_categoria;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use PDOException;

class NoticiaController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
    }
    public function index(){
        $dados_geral = DB::table('noticias')
        ->join('users', 'users.id', '=', 'noticias.users_id')
        ->select('*','noticias.id As id')
        ->get();

       
        return view("pages.noticias", compact('dados_geral'));       
    }
    public function create(){
        $categorias = Categoria::all();
        return view('pages.noticias_cadastro', compact('categorias'));   
    } 
    public function store(Request $request){
 
        $noiticia = $request->input('id_noticia');

        $idscategoria = $request->input('id_categorias');
        $idscategoria = explode(",", $idscategoria);
        
        Noticia_categoria::where('noticias_id', $noiticia)->delete();

        foreach($idscategoria as $val){
            if($val != ''){
                $dados_cat = new Noticia_categoria();
                $dados_cat->noticias_id = $noiticia;
                $dados_cat->categorias_id = $val;
                $dados_cat->save(); 
            }           
        }        
        if($noiticia == ''){
            // CADASTRA
            $dados = new Noticia();
        }else{
            // ATUALIZA
            $dados = Noticia::find($noiticia);
        }
            $dados->titulo = $request->input('titulo');
            $dados->users_id = Auth::user()->id;
            $dados->status = $request->input('status');
            $dados->resumo = $request->input('resumo');
            $dados->img_url = $request->input('img_url');
            $dados->destaque = $request->input('destaque');
            $dados->banner = $request->input('banner');
            $dados->texto = $request->input('descricao');
            $dados->save();            
            return $dados->id;
    }
    
    public function edit($id){
      $dados_geral = Noticia::find($id);
      $categorias = Categoria::all();
      return view('pages.noticias_cadastro', compact('dados_geral','categorias'));     
    }

    public function show($id){
        $destaque = DB::table('noticias')
        ->join('users', 'users.id', '=', 'noticias.users_id')
        ->leftjoin('noticia_categorias', 'noticia_categorias.id', '=', 'noticias.id')
        ->leftjoin('categorias', 'categorias.id', '=', 'noticias.categorias_id')
        ->where("noticias.destaque", '1')
        ->select('*','noticias.id As id', 'categorias.nome As cnome')
        ->orderBy('noticias.id', 'desc')
        ->get();

        $menu = DB::table('noticia_categorias')
        ->join('categorias', 'categorias.id', '=', 'noticia_categorias.categorias_id')
        ->select('*','categorias.id As id')
        ->groupBy('categorias.nome')
        ->orderBy('categorias.nome', 'desc')
        ->get();

        $elementActive = 'HOME';  

        $dados_geral = Noticia::find($id);
        return view('pages.noticias_show', compact('dados_geral','destaque','menu','elementActive'));  

    }

    public function getidgategorias($id){
        $dados_geral = Noticia_categoria::where('noticias_id', $id)->get();
        $ids = '';
        foreach ($dados_geral as $value){
            $ids .= $value->categorias_id.',';
        }
        return $ids;
    }


    public function destroy($id){

      $dados = Noticia::find($id);
      echo var_dump($dados);
      if(isset($dados)){
          try {
              $dados->delete();
              Session::put('message', 'Removido com sucesso!');
              return redirect("/noticias");                
          }catch (PDOException $e) {
              if (isset($e->errorInfo[1]) && $e->errorInfo[1] == '1451') {
                  Session::put('message', 'Erro, essa <b>Notícia</b> esta em uso em outro relacionamento.');
                  return redirect("/noticias");
              }
          }
      }
    }
}
